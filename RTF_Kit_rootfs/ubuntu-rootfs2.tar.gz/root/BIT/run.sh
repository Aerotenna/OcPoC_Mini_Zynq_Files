#!/bin/sh

# This Shell Script runs Ardupilot for a little bit and looks to see if the CAN system is still working
# First we run arducopter for a little bit
# can_landing_test is actually a mutation on Arudpilot
timeout 10 ./can_landing_test -E /dev/ttyS6 > /dev/null
# awk script to search for select responses from Ardupilot
mawk -f can_landing.awk /root/prox_log || echo "FAIL: No CAN or uLanding detected"
# We clean up after ourselves
rm -f /root/prox_log
# Finally we run through the sensors, in theory we could do a similar thing with ardupilot
./sensors_test
