#!/bin/sh
cd /home
./*.elf -C /dev/ttyPS1
